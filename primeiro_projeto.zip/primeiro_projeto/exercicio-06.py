#Resolução de inversão de dois numeros armazenados a variavel.
a = 5
b = 10
c = 0
print(f"A: {a} \n B: {b}")
c = b
b = a
a = c
print(f"A: {a} \n B: {b}")
