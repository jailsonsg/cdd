numero = int(input("Digite um número: "))
if numero % 2 == 0:
    print("O numero digitado é PAR")
else:
    print("O numero digitado é IMPAR")