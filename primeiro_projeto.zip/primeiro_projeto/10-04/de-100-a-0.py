for numero in range(100,-1,-1):
    print(numero)