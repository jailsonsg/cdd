duracaoMaxima = 24
horaInicio = int(input("Digite a hora de inicio da partida: "))
horaFim = int(input("Digite a hora do final da partida: "))
duracaoPartida = horaFim - horaInicio
if horaFim > duracaoMaxima :
    duracaoPartida = duracaoPartida - 24
    print(f"A partida durou {duracaoPartida} horas")
elif duracaoPartida < 20:
    duracaoPartida = duracaoPartida + 24
    print(f"A partida durou {duracaoPartida} horas")
