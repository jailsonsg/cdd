totalEleitores = int(input("Digite o número total de eleitores: "))
votosValidos = int(input("Digite a quantidade de votos válidos: "))
votosBrancos = int(input("Digite a quantidade de votos brancos: "))
votosNulos = int(input("Digite a quantidade de votos nulos: "))

percentualValidos = (votosValidos/totalEleitores)*100
percentualBrancos = (votosBrancos/totalEleitores)*100
percentualNulos = (votosNulos/totalEleitores)*100
print("Os votos válidos tem a taxa de: ", percentualValidos,"%")
print("Os votos brancos tem a taxa de: ", percentualBrancos,"%")
print("Os votos nulos tem a taxa de: ", percentualNulos,"%")
print("Total de eleitores:", totalEleitores)
