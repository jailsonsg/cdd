numero1 = int(input("Digite o primeiro número: "))
numero2 = int(input("Digite o segundo número: "))
if numero1 > numero2:
    print(numero2, numero1)
else:
    print(numero1, numero2)