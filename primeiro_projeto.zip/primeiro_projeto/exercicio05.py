# Programa que solicita dois numeros e realiza 4 operações aritmeticas com os numeros digitados.
numero1 = float(input("Digite o primeiro numero: "))
numero2 = float(input("Digite o segundo numero: "))

soma = numero1 + numero2
print(f"A soma dos numeros digitados é {soma}")
subtracao = numero1 - numero2
print(f"A subtração dos numeros digitados é {subtracao}")
multiplicacao = numero1 * numero2
print(f"A multiplicação dos numeros digitados é {multiplicacao}")
divisao = numero1 / numero2
print(f"A divisao dos numeros digitados é {divisao}")