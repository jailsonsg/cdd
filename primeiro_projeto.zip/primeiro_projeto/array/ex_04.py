'''Código que permita a leitura das notas de um turma de 5 alunos e guarde num vetor,
Calcular a média da turma e contar quantos alunos obtiveram nota acima desta média calculada.
Escrever a média da turma e o resultado da contagem.'''
notas = ["","","","",""]
# for para solicitar as notas e guardar no vetor
for x in range(5):
    notas[x] = float(input("Digite sua nota: "))
# for para calcular a média
soma = 0
contador = 0
media = 0
acimaDaMedia = 0
for y in range(5):
    soma = soma + notas[y]
    mediaDaTurma = soma/5
#for para contar alunos que estão acima da média da turma.
acimaDaMedia = 0
for z in range(5):
    if notas[z] >= mediaDaTurma:
        acimaDaMedia = acimaDaMedia + 1
print(f"A média da turma é {mediaDaTurma} e {acimaDaMedia} alunos estão acima da média: ")