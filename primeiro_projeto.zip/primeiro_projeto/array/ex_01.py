#Crie um array tamanho 5 e preencher com os nomes dos 5 alunos, informados pelo usuário. e mostrar separadamente seu nome e sua posição.a
nomes = ["","","","",""]
for x in range(5):
    solicitacaoNomes = input("Digite o seu nome: ")
    nomes[x] = solicitacaoNomes
for y in range(5):
    print(f"{nomes[y]} está na posição: {y}")






