'''Preencher um vetor A com 10 números.
Logo em seguida, ler mais um número e guardar em uma variavel X.
Armazenar em vetor M o resultado de cada elemento de A multiplicado pelo valor X.
No final imprimir o vetor M.'''
a = ['','','','','','','','','','',]
m = ['','','','','','','','','','']
# for que preenche o vetor com 10 elementos]
for x in range(10):
    a[x] = int(input("Digite um número: "))
x = int(input("Digite o multiplicador: "))
#for para armazenar o resultado de cada elemento de A multiplicado por X.
for y in range(10):
        m[y] = a[y] * x
print(a)
print(x)
print(m)