# pesquisar sobre a biblioteca numpy
m = [8.0,"José",True,7]
print(m)
print(m[0])
print(m[1])
print(m[2])
print(m[3])