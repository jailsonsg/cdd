''' Ler 5 nomes de usuários e suas respectivas senhas
armazenar cada lista em um array diferente
após completar a digitação, imprimir nome,senha e posição do dados no array.
'''
nomes = ['','','','','']
senhas = ['','','','','']
print("CADASTRO DE CLIENTES")
for x in range(5):
    nomes[x] = input("Digite o nome: ")
    senhas[x] = input("Digite a senha: ")

for y in range(5):
    print("Nome |",nomes[y],"|", "Senha| ",senhas[y],"|", "Posição| ", y)