from classes import *

p1 = Pessoa("Jailson",22,74.7,)
p1.comer("Uva")
p1.pararDeComer()
p1.comer("Melão")
p1.falar("Oi")