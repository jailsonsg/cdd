# def = para criar uma função em python
def funcao():
    print("Bloco de código")

# a função só é utilizada quando chamar ela.
funcao()

# parâmetros
def imprime_nome(nome):
        print(f"Nome: {nome}")

imprime_nome("Jailson")
