'''
Crie uma função que recebe o nome de um produto, a quantidade que tem no estoque e o valor unitario do produto
retorne o valor total do meu estoque.
'''

def verificaNumero(numero):
    if numero > 0:
        return "P"
    elif numero < 0:
        return "N"
    else:
        return "Z"

n = int(input("Digite um numero: "))
exibirResultado =verificaNumero(n)
print(exibirResultado)


