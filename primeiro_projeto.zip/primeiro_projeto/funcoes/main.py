from funcoes import *

contaLetras = trata_texto("jose")
print(contaLetras)
