numero = int(input("Digite um número: "))
for linha in range(1, numero+1):
    for coluna in range(1,linha+1):
     print(linha, end=" ")
    print()


