n1 = int(input("Digite um valor: "))
n2 = int(input("Digite um valor: "))
n3 = int(input("Digite um valor: "))
n4 = int(input("Digite um valor: "))
soma = (n1+n2+n3+n4)
media = soma/4
print(f"A soma dos valores é {soma} e a media é {media}")