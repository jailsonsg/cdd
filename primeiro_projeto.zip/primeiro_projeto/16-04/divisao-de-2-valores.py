valor1 = float(input("Digite o numero 1: "))
valor2 = float(input("Digite o numero 2: "))
while valor2 == 0:
    valor2 = float(input("Digite um valor diferente de 0: "))
print(valor1/valor2)