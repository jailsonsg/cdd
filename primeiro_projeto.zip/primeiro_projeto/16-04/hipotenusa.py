menu = input("1 - Calcular área do triângulo \n 2 - Calcular a área do quardrado \n 3 para encerrar o programa: ")
validacao = False
while validacao == False:
    if menu == "1":
        base = float(input("Digite a base do triangulo: "))
        altura = float(input("Digite a altura do triangulo: "))
        areaTriangulo = (base*altura)/2
        print(f"A área do triangulo é : {areaTriangulo}")
        menu = input("1 - Calcular área do triângulo \n 2 - Calcular a área do quardrado \n 3 para encerrar o programa: ")
    elif menu == "2":
        lado = int(input("Digite o tamanho do lado do quadrado: "))
        areaQuadrado = lado**2
        print(f"A área do quadrado é : {areaQuadrado}")
        menu = input("1 - Calcular área do triângulo \n 2 - Calcular a área do quardrado \n 3 para encerrar o programa: ")
    elif menu == "3":
        validacao = True
        print("Fim do programa.")
    else:
        print("Número inválido. Digite um número entre as opções.")
        menu = input("1 - Calcular área do triângulo \n 2 - Calcular a área do quardrado \n 3 para encerrar o programa: ")

