numero = int(input("Digite um numero: "))
if numero % 2 == 0:
    print("O numero é par ")
else:
    print("O numero é impar ")