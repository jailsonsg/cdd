anos = int(input("Digite sua idade em anos: "))
meses = int(input("Digite seus meses: "))
dias = int(input("Digite agora os dias: "))
anosEmDias = anos * 365
mesesEmDias = meses * 30
print(anosEmDias+mesesEmDias+dias)
