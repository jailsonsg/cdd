numero = int(input("Digite um numero inteiro: "))
print(f"O antecessor do numero digitado é {numero-1}")
print(f"O sucessor do numero digitado é {numero+1}")