inicio = 0
while inicio < 10:
    print(inicio)
    inicio += 1