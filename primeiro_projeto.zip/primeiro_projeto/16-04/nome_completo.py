"""Escreva um código que solicite o
nome completo do usuário e mostre
quantas letras tem esse nome"""
nome = input("Digite seu nome completo: ")
contador =0
for caracter in nome:
    contador += 1
print(f"Seu nome tem {contador} letras ")
