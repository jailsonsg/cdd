#Programa que exibe de 1 até 10.
for numero in range (1,11,1):
    print(numero)